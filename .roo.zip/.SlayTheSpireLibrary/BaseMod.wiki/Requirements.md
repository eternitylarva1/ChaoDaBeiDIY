# General Use
* Java 1.8
* ModTheSpire (https://github.com/kiooeht/ModTheSpire/releases)

# Development
* Java 1.8
* ModTheSpire (https://github.com/kiooeht/ModTheSpire/releases)
* Maven
* Java Decompiler - jd-gui is a good option (http://jd.benow.ca/)