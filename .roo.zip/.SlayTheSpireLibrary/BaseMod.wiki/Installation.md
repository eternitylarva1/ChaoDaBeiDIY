# THIS IS OUTDATED. PLEASE USE THE STEAM WORKSHOP RELEASE
# Steps
1. Download the latest release from (https://github.com/daviscook477/BaseMod/releases)
2. Copy `BaseMod.jar` into your `mods` folder for **ModTheSpire** (https://github.com/kiooeht/ModTheSpire)